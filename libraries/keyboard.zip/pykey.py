sample = {
        "rot": [0,0,0],
        "trans": [0,0,0],
        "pos": [0,0]
    }




edges = """
    hull() {{
        translate({trans1})
            inter(e="{edge1}", r={rot1});
        translate({trans2})
            inter(e="{edge2}", r={rot2});
    }}
"""

edge = """
    translate({trans}){{
        t(e=0, v=0, r={rot});
        l(e=0, v=0, r={rot});
        b(e=0, v=0, r={rot});
        r(e=0, v=0, r={rot});
    }}
"""


corners = """
    hull() {{
        translate({t1})
            inter(e="{e1}", r={r1});
        translate({t2})
            inter(e="{e2}", r={r2});
        translate({t3})
            inter(e="{e3}", r={r3});
        translate({t4})
            inter(e="{e4}", r={r4});
    }}
"""
wall = """
    translate({t})
        wall(e="{e}", r={r});
"""

key = "translate({trans}){{key(r={rot});}}"
keycap = "translate({trans}){{keycap(r={rot});}}"
keyswitch = "translate({trans}){{keyswitch(r={rot});}}"

keycaps = []
keyswitches = []
keyplate = []
keymatrix = []

walls = []

def generate(w, h):
    m = []
    for y in range(h):
        m_row = []
        z = 0
        if y == int(h/2):
            z = 2
        for x in range(w):
            
            tmp = dict(sample)
            tmp["pos"] = [y, x]
            tmp["trans"] = [x*1905/100, y*1905/100, abs(y-2)*3]
            # tmp["rot"] = [(y-2)*10, 0, 0]
            tmp["rot"] = [(y-2)*5, 0, 0]
            m_row.append(tmp)
        m.append(m_row)
    return m

matrix = generate(w=7, h=5)

def neighbours(x, y):
    n = {"up": None, "down":None, "left":None, "right":None}  # up, down, left, right
    if x > 0:
        n["left"] = matrix[y][x-1]  # left
    if x < len(matrix[y])-1:
        n["right"] = matrix[y][x+1]  # right
    if y > 0:
        n["down"] = matrix[y-1][x]  # up
    if y < len(matrix)-1:
        n["up"] = matrix[y+1][x]  # down
    return n

def diagonal(x, y):
    d = {"up_left": None, "up_right": None, "down_left": None, "down_right": None}  # up_left, up_right, down_left, down_right
    if x > 0 and y > 0:
        d["down_left"] = matrix[y-1][x-1]  # up_left
    if x < len(matrix[y])-1 and y > 0:
        d["down_right"] = matrix[y-1][x+1]  # up_right
    if x > 0 and y < len(matrix)-1:
        d["up_left"] = matrix[y+1][x-1]  # down_left
    if x < len(matrix[y])-1 and y < len(matrix)-1:
        d["up_right"] = matrix[y+1][x+1]  # down_right
    return d

def intersections(x, y):
    neigh = neighbours(x, y)
    diag = diagonal(x, y)
    if diag["up_left"]:
        print("// North West corner")
        print("hull() {")

        print("color(\"#f00\")translate({})tl(v=0, r={});".format(matrix[y][x]["trans"], matrix[y][x]["rot"]))
        print("color(\"#0f0\")translate({})br(v=0, r={});".format(diag["up_left"]["trans"], diag["up_left"]["rot"]))
        # print("}")
        if(neigh["up"]):
            print("color(\"#00f\")translate({})bl(v=0, r={});".format(neigh["up"]["trans"], neigh["up"]["rot"]))
        if(neigh["left"]):
            print("color(\"#0ff\")translate({})tr(v=0, r={});".format(neigh["left"]["trans"], neigh["left"]["rot"]))
        print("}")
    # if diag["up_right"]:
    #     print("// North East corner")
    #     print("hull() {")
    #     print("translate({})t(e=1, v=0, r={});".format(matrix[y][x]["trans"], matrix[y][x]["rot"]))
    #     print("translate({})b(e=1,v=0, r={});".format(diag["up_right"]["trans"], diag["up_right"]["rot"]))
    #     if(neigh["up"]):
    #         print("translate({})b(e=-1, v=0, r={});".format(neigh["up"]["trans"], neigh["up"]["rot"]))
    #     if(neigh["right"]):
    #         print("translate({})t(e=-1, v=0, r={});".format(neigh["right"]["trans"], neigh["right"]["rot"]))
    #     print("}")
        
    # if diag["down_left"]:
    #     print("// South West corner")
    #     print("hull() {")
    #     print("translate({})b(e=1, v=0, r={});".format(matrix[y][x]["trans"], matrix[y][x]["rot"]))
    #     print("translate({})t(e=1, v=0, r={});".format(diag["down_left"]["trans"], diag["down_left"]["rot"]))
    #     if(neigh["down"]):
    #         print("translate({})t(e=-1, v=0, r={});".format(neigh["down"]["trans"], neigh["down"]["rot"]))
    #     if(neigh["left"]):
    #         print("translate({})b(e=-1, v=0, r={});".format(neigh["left"]["trans"], neigh["left"]["rot"]))
    #     print("}")
    # if diag["down_right"]:
    #     print("// South East corner")
    #     print("hull() {")
    #     print("translate({})b(e=-1, v=0, r={});".format(matrix[y][x]["trans"], matrix[y][x]["rot"]))
    #     print("translate({})t(e=-1, v=0, r={});".format(diag["down_right"]["trans"], diag["down_right"]["rot"]))
    #     if(neigh["down"]):
    #         print("translate({})t(e=1, v=0, r={});".format(neigh["down"]["trans"], neigh["down"]["rot"]))
    #     if(neigh["right"]):
    #         print("translate({})b(e=1, v=0, r={});".format(neigh["right"]["trans"], neigh["right"]["rot"]))
    #     print("}")

def model(x, y):
    # print(matrix[y][x])
    neigh = neighbours(x, y)
    # diag = diagonal(x, y)
    # if diag["up_left"]:
    #     print("hull() {")
    #     print("translate({})t(e=-1, v=0, r={});".format(matrix[y][x]["trans"], matrix[y][x]["rot"]))
    #     print("translate({})b(e=-1,v=0, r={});".format(diag["up_left"]["trans"], diag["up_left"]["rot"]))
    #     if(neigh["up"]):
    #         print("translate({})b(e=1, v=0, r={});".format(neigh["up"]["trans"], neigh["up"]["rot"]))
    #     if(neigh["left"]):
    #         print("translate({})t(e=1, v=0, r={});".format(neigh["left"]["trans"], neigh["left"]["rot"]))
    #     print("}")
    # else:
    #     print("// North West corner")
    # if diag["up_right"]:
    #     # print("hull() {")
    #     print("translate({})tr(v=0, r={});".format(matrix[y][x]["trans"], matrix[y][x]["rot"]))
    #     print("translate({})bl(v=0, r={});".format(diag["up_right"]["trans"], diag["up_right"]["rot"]))
    #     if(neigh["up"]):
    #         print("translate({})br(v=0, r={});".format(neigh["up"]["trans"], neigh["up"]["rot"]))
    #     if(neigh["right"]):
    #         print("translate({})tl(v=0, r={});".format(neigh["right"]["trans"], neigh["right"]["rot"]))
    #     # print("}")
    # else:
    #     print("// North East corner")
    # if diag["down_left"]:
    #     # print("hull() {")
    #     print("translate({})bl(v=0, r={});".format(matrix[y][x]["trans"], matrix[y][x]["rot"]))
    #     print("translate({})tr(v=0, r={});".format(diag["down_left"]["trans"], diag["down_left"]["rot"]))
    #     if(neigh["down"]):
    #         print("translate({})tl(v=0, r={});".format(neigh["down"]["trans"], neigh["down"]["rot"]))
    #     if(neigh["left"]):
    #         print("translate({})br(v=0, r={});".format(neigh["left"]["trans"], neigh["left"]["rot"]))
    #     # print("}")
    # else:
    #     print("// South West corner")
    # if diag["down_right"]:
    #     # print("hull() {")
    #     print("translate({})br(v=0, r={});".format(matrix[y][x]["trans"], matrix[y][x]["rot"]))
    #     print("translate({})tl(v=0, r={});".format(diag["down_right"]["trans"], diag["down_right"]["rot"]))
    #     if(neigh["down"]):
    #         print("translate({})tr(v=0, r={});".format(neigh["down"]["trans"], neigh["down"]["rot"]))
    #     if(neigh["right"]):
    #         print("translate({})bl(v=0, r={});".format(neigh["right"]["trans"], neigh["right"]["rot"]))
    #     # print("}")
    # else:
    #     print("// South East corner")

    if neigh["down"]:
#         t = """
# hull() {{
#    translate({}){}(e=0, v=0, r={});
#    translate({}){}(e=0, v=0, r={});
# }}
# """
        print("hull() {")
        print("translate({})b(e=0, v=0, r={});".format(matrix[y][x]["trans"], matrix[y][x]["rot"]))
        print("translate({})t(e=0, v=0, r={});".format(neigh["down"]["trans"], neigh["down"]["rot"]))
        print("}")

    else:
        print("// South wall")
        print("hull() {")
        print("translate({})scale([1.2,1.1,1])b(e=0, v=0, r={});".format(matrix[y][x]["trans"], matrix[y][x]["rot"]))
        print("translate({})scale([1.5,1.1,1])b(e=0, v=1, r=[0,0,0]);".format([matrix[y][x]["trans"][0], matrix[y][x]["trans"][1], -10]))
        print("translate({})scale([1.3,1.1,1])l(e=-1,v=1, r=[0,0,0]);".format([matrix[y][x]["trans"][0], matrix[y][x]["trans"][1], -10]))
        print("translate({})scale([1.3,1.1,1])r(e=1,v=1, r=[0,0,0]);".format([matrix[y][x]["trans"][0], matrix[y][x]["trans"][1], -10]))
        
        print("translate({})b(e=0, v=0, r={});".format(matrix[y][x]["trans"], matrix[y][x]["rot"]))
        print("translate({})b(e=0, v=1, r=[0,0,0]);".format([matrix[y][x]["trans"][0], matrix[y][x]["trans"][1], -10]))
        print("translate({})l(e=-1,v=1, r=[0,0,0]);".format([matrix[y][x]["trans"][0], matrix[y][x]["trans"][1], -10]))
        print("translate({})r(e=1,v=1, r=[0,0,0]);".format([matrix[y][x]["trans"][0], matrix[y][x]["trans"][1], -10]))
        print("}")
    if neigh["up"]:
        print("hull() {")
        print("translate({})t(e=0, v=0, r={});".format(matrix[y][x]["trans"], matrix[y][x]["rot"]))
        print("translate({})b(e=0, v=0, r={});".format(neigh["up"]["trans"], neigh["up"]["rot"]))
        print("}")
        # print("translate({})b(e=0, v=0, r={});".format(neigh["down"]["trans"], neigh["down"]["rot"]))
    else:
        print("// North wall")
        print("hull() {")
        print("translate({})scale([1.2,1.1,1])t(e=0, v=0, r={});".format(matrix[y][x]["trans"], matrix[y][x]["rot"]))
        print("translate({})scale([1.5,1.1,1])t(e=0, v=1, r=[0,0,0]);".format([matrix[y][x]["trans"][0], matrix[y][x]["trans"][1], -10]))
        print("translate({})scale([1.3,1.1,1])r(e=-1,v=1, r=[0,0,0]);".format([matrix[y][x]["trans"][0], matrix[y][x]["trans"][1], -10]))
        print("translate({})scale([1.3,1.1,1])l(e=1,v=1, r=[0,0,0]);".format([matrix[y][x]["trans"][0], matrix[y][x]["trans"][1], -10]))
        
        print("translate({})t(e=0, v=0, r={});".format(matrix[y][x]["trans"], matrix[y][x]["rot"]))
        print("translate({})t(e=0, v=1, r=[0,0,0]);".format([matrix[y][x]["trans"][0], matrix[y][x]["trans"][1], -10]))
        print("translate({})r(e=-1,v=1, r=[0,0,0]);".format([matrix[y][x]["trans"][0], matrix[y][x]["trans"][1], -10]))
        print("translate({})l(e=1,v=1, r=[0,0,0]);".format([matrix[y][x]["trans"][0], matrix[y][x]["trans"][1], -10]))
        print("}")
    if neigh["left"]:
        print("hull() {")
        print("translate({})l(e=0, v=0, r={});".format(matrix[y][x]["trans"], matrix[y][x]["rot"]))
        print("translate({})r(e=0, v=0, r={});".format(neigh["left"]["trans"], neigh["left"]["rot"]))
        print("}")
        # print("translate({})l(e=0, v=0, r={});".format(neigh["left"]["trans"], neigh["left"]["rot"]))
    else:
        print("// West wall")
        print("hull() {")
        # if neigh["up"]:
        #     print("translate({})b(e=1, v=0, r={});".format(neigh["up"]["trans"], neigh["up"]["rot"]))
        print("translate({})scale([1.2,1.1,1])l(e=0, v=0, r={});".format(matrix[y][x]["trans"], matrix[y][x]["rot"]))
        print("translate({})scale([1.5,1.1,1])l(e=0, v=1, r=[0,0,0]);".format([matrix[y][x]["trans"][0], matrix[y][x]["trans"][1], -10]))
        print("translate({})scale([1.3,1.1,1])t(e=-1,v=1, r=[0,0,0]);".format([matrix[y][x]["trans"][0], matrix[y][x]["trans"][1], -10]))
        print("translate({})scale([1.3,1.1,1])b(e=1,v=1, r=[0,0,0]);".format([matrix[y][x]["trans"][0], matrix[y][x]["trans"][1], -10]))
        
        print("translate({})l(e=0, v=0, r={});".format(matrix[y][x]["trans"], matrix[y][x]["rot"]))
        print("translate({})l(e=0, v=1, r=[0,0,0]);".format([matrix[y][x]["trans"][0], matrix[y][x]["trans"][1], -10]))
        print("translate({})t(e=-1,v=1, r=[0,0,0]);".format([matrix[y][x]["trans"][0], matrix[y][x]["trans"][1], -10]))
        print("translate({})b(e=1,v=1, r=[0,0,0]);".format([matrix[y][x]["trans"][0], matrix[y][x]["trans"][1], -10]))
        print("}")
    if neigh["right"]:
        print("hull() {")
        print("translate({})r(e=0, v=0, r={});".format(matrix[y][x]["trans"], matrix[y][x]["rot"]))
        print("translate({})l(e=0, v=0, r={});".format(neigh["right"]["trans"], neigh["right"]["rot"]))
        print("}")
        # print("translate({})r(e=0, v=0, r={});".format(neigh["right"]["trans"], neigh["right"]["rot"]))
    else:
        print("// East wall")
        print("hull() {")
        # if neigh["up"]:
        #     print("translate({})r(e=1, v=0, r={});".format(neigh["up"]["trans"], neigh["up"]["rot"]))
        print("translate({})scale([1.2,1.1,1])r(e=0, v=0, r={});".format(matrix[y][x]["trans"], matrix[y][x]["rot"]))
        print("translate({})scale([1.5,1.1,1])r(e=0, v=1, r=[0,0,0]);".format([matrix[y][x]["trans"][0], matrix[y][x]["trans"][1], -10]))
        print("translate({})scale([1.3,1.1,1])t(e=1,v=1, r=[0,0,0]);".format([matrix[y][x]["trans"][0], matrix[y][x]["trans"][1], -10]))
        print("translate({})scale([1.3,1.1,1])b(e=-1,v=1, r=[0,0,0]);".format([matrix[y][x]["trans"][0], matrix[y][x]["trans"][1], -10]))
        
        print("translate({})r(e=0, v=0, r={});".format(matrix[y][x]["trans"], matrix[y][x]["rot"]))
        print("translate({})r(e=0, v=1, r=[0,0,0]);".format([matrix[y][x]["trans"][0], matrix[y][x]["trans"][1], -10]))
        print("translate({})t(e=1,v=1, r=[0,0,0]);".format([matrix[y][x]["trans"][0], matrix[y][x]["trans"][1], -10]))
        print("translate({})b(e=-1,v=1, r=[0,0,0]);".format([matrix[y][x]["trans"][0], matrix[y][x]["trans"][1], -10]))
        print("}")
    print("translate({})key_holder(r={});".format(matrix[y][x]["trans"], matrix[y][x]["rot"]))
    # print("translate({})t(e=0, v=0, r={});".format(matrix[y][x]["trans"], matrix[y][x]["rot"]))
    # print("translate({})b(e=0, v=0, r={});".format(matrix[y][x]["trans"], matrix[y][x]["rot"]))
    # print("translate({})l(e=0, v=0, r={});".format(matrix[y][x]["trans"], matrix[y][x]["rot"]))
    # print("translate({})r(e=0, v=0, r={});".format(matrix[y][x]["trans"], matrix[y][x]["rot"]))
# model(0,1)

print("include <keyboard/keeb.scad>;")
for y in range(len(matrix)):
    for x in range(len(matrix[y])):
        intersections(x,y)
        model(x,y)
# def generate(w, h):
#     m = []
#     for y in range(h):
#         m_row = []
#         z = 0
#         if y == int(h/2):
#             z = 2
#         for x in range(w):
            
#             tmp = dict(sample)
#             tmp["pos"] = [y, x]
#             tmp["trans"] = [x*1905/100, (y-1)*1905/100+(y-1)*3, abs(y-1)*19]
#             tmp["rot"] = [(y-1)*80, 0, 0]
#             m_row.append(tmp)
#         m.append(m_row)
#     return m

# matrix = generate(w=4, h=3)

for y in range(len(matrix)):
    for x in range(len(matrix[y])):
        keycaps.append(keycap.format(trans=matrix[y][x]["trans"], rot=matrix[y][x]["rot"]))
        keyswitches.append(keyswitch.format(trans=matrix[y][x]["trans"], rot=matrix[y][x]["rot"]))
        keymatrix.append(key.format(trans=matrix[y][x]["trans"], rot=matrix[y][x]["rot"]))
        if y < len(matrix)-1:
            keyplate.append(edges.format(trans1=matrix[y][x]["trans"], edge1="t", rot1=matrix[y][x]["rot"], trans2=matrix[y+1][x]["trans"], edge2="b", rot2=matrix[y+1][x]["rot"]))
        if x < len(matrix[y])-1:
            keyplate.append(edges.format(trans1=matrix[y][x]["trans"], edge1="r", rot1=matrix[y][x]["rot"], trans2=matrix[y][x+1]["trans"], edge2="l", rot2=matrix[y][x+1]["rot"]))
        
        if x < len(matrix[y])-1 and y < len(matrix)-1:
            keyplate.append(corners.format(
                t1=matrix[y][x]["trans"], e1="tr", r1=matrix[y][x]["rot"],
                t2=matrix[y+1][x]["trans"], e2="br", r2=matrix[y+1][x]["rot"],
                t3=matrix[y+1][x+1]["trans"], e3="bl", r3=matrix[y+1][x+1]["rot"],
                t4=matrix[y][x+1]["trans"], e4="tl", r4=matrix[y][x+1]["rot"]
            ))
        if x == 0:
            walls.append(wall.format(t=matrix[y][x]["trans"], e="l", r=matrix[y][x]["rot"]))
        if x == len(matrix[y])-1:
            walls.append(wall.format(t=matrix[y][x]["trans"], e="r", r=matrix[y][x]["rot"]))
        if y == 0:
            walls.append(wall.format(t=matrix[y][x]["trans"], e="b", r=matrix[y][x]["rot"]))
        if y == len(matrix)-1:
            walls.append(wall.format(t=matrix[y][x]["trans"], e="t", r=matrix[y][x]["rot"]))
        if x== 0 and y == 0:
            walls.append(wall.format(t=matrix[y][x]["trans"], e="bl", r=matrix[y][x]["rot"]))
        if x== 0 and y == len(matrix)-1:
            walls.append(wall.format(t=matrix[y][x]["trans"], e="tl", r=matrix[y][x]["rot"]))
        if x == len(matrix[y])-1 and y == 0:
            walls.append(wall.format(t=matrix[y][x]["trans"], e="br", r=matrix[y][x]["rot"]))
        if x == len(matrix[y])-1 and y == len(matrix)-1:
            walls.append(wall.format(t=matrix[y][x]["trans"], e="tr", r=matrix[y][x]["rot"]))

mod = """
module {name}() {{
    {content}
}}
if(display_{name}) {{ {color}{name}(); }}

"""

# print("""include <keeb.scad>;
    
# key_travel = 1.6;
# keycap_height = 8;
# keycap_color = "#eee";
# travel_color = "#f369";
# plate_color = "#669";
# display_plate = false;
# display_errors = false;
# display_walls = false;
# display_switches = false;
# display_keycaps = false;
# display_travel=true;

# module hide() {{}};
# display_matrix = false;
# display_keyplate = false;
# """)


# print(mod.format(name="switches", color="", content="\n\t".join(keyswitches)))
# print(mod.format(name="keycaps", color="", content="\n\t".join(keycaps)))
# print(mod.format(name="keyplate", color="", content="\n\t".join(keyplate)))
# print(mod.format(name="matrix", color="", content="\n\t".join(keymatrix)))
# print(mod.format(name="plate", color="", content="color(plate_color) union(){\n\t\tkeyplate(); \n\t\tmatrix(); \n\t}"))
# print(mod.format(name="errors", color="", content="color(\"#f00\")intersection() {\n\t\tplate();\n\t\tkeycaps();\n\t}"))

# print(mod.format(name="walls", color="", content="\n\t".join(walls)))